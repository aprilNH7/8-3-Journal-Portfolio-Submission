package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CreateAccountActivity extends AppCompatActivity {
    private EditText usernameInput;
    private EditText passwordInput;
    private EditText confirmPasswordInput;
    private Button createAccountButton;
    private DatabaseHandler db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        usernameInput = findViewById(R.id.usernameInput);
        passwordInput = findViewById(R.id.passwordInput);
        confirmPasswordInput = findViewById(R.id.confirmPasswordInput);
        createAccountButton = findViewById(R.id.createAccountButton);

        db = new DatabaseHandler(this);

        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                attemptAccountCreation();
            }
        });
    }

    private void attemptAccountCreation() {
        String username = usernameInput.getText().toString().trim();
        String password = passwordInput.getText().toString().trim();
        String confirmPassword = confirmPasswordInput.getText().toString().trim();

        // Input Validation
        if (username.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!password.equals(confirmPassword)) {
            Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
            return;
        }

        // More robust validation if needed (password complexity, etc.)
        // ...

        // IMPORTANT: Replace with password hashing mechanism
        String hashedPassword = hashPassword(password);

        User newUser = new User(0, username, hashedPassword);
        db.addUser(newUser);

        Toast.makeText(this, "Account created!", Toast.LENGTH_SHORT).show();

        // Redirect user to login or main activity
        // ...
        Intent intent = new Intent(CreateAccountActivity.this, LoginActivity.class);
    }

    // Placeholder - Implement a secure password hashing mechanism
    private String hashPassword(String password) {
        // Use a robust library like bcrypt or scrypt
        return password;
    }
}
